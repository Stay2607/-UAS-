a = float(input("\nMasukkan sisi a : "))
b = float(input("Masukkan sisi b : "))
c = float(input("Masukkan sisi c : "))
if a == b and b == c:
    print("\nTerdapat 3 sisi yang sama!")
    print("Segitiga tersebut merupakan segitiga sama sisi.")
elif a == c and a != b:
    print("\nTerdapat 2 sisi yang sama, yaitu a dan c!")
    print("Segitiga tersebut merupakan segitiga sama kaki.")
elif a == b and a != c:
    print("\nTerdapat 2 sisi yang sama, yaitu a dan b!")
    print("Segitiga tersebut merupakan segitiga sama kaki.")
elif a != b and a != c and b != a and b != c and c != a and c != b:
    print("\nTidak terdapat sisi yang sama!")
    print("Segitiga tersebut merupakan segitiga sembarang.")
elif a < 1 and b < 1 and c < 1:
    print("Invalid input!")
else:
    print("\nTerdapat 2 sisi yang sama, yaitu b dan c!")
    print("Segitiga tersebut merupakan segitiga sama kaki.")